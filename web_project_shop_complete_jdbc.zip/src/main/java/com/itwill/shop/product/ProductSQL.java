package com.itwill.shop.product;

public class ProductSQL {
	public final static String PRODUCT_SELECT_ALL=
			"select * from product";
	public final static String PRODUCT_SELECT_BY_NO=
			"select * from product where p_no=?";
	
	
}
